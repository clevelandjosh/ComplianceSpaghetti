from json2parquet import convert_json, load_json, ingest_data, write_parquet, write_parquet_dataset
import sys
import os
import subprocess

input_filename = sys.argv[1]

output_filename = os.path.splitext(input_filename)[0]+'.parquet'

print(input_filename)
print(output_filename)

# Infer Schema (requires reading dataset for column names)
# convert_json(input_filename, output_filename)
initial_data = json.loads(json.dumps(input_filename))

data = load_json(initial_data)
write_parquet(data, output_filename)

date_format = "%Y-%m-%dT%H:%M:%S.%fZ"
convert_json(input_filename, output_filename, date_format=date_format)



# Given columns
# convert_json(input_filename, output_filename, ["my_column", "my_int"])

# Given columns and custom field names
# field_aliases = {'my_column': 'my_updated_column_name', "my_int": "my_integer"}
# convert_json(input_filename, output_filename, ["my_column", "my_int"], field_aliases=field_aliases)


# Given PyArrow schema
# import pyarrow as pa
# schema = pa.schema([
#     pa.field('my_column', pa.string),
#    pa.field('my_int', pa.int64),
# ])
# convert_json(input_filename, output_filename, schema)
